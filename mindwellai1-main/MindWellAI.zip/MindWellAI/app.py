# Mental Wellness Assistant Flask Application
# Integrated with Replit's OpenAI blueprint for AI features

import os
import sqlite3
from datetime import datetime
from flask import Flask, request, jsonify, render_template, redirect, url_for, session
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from openai import OpenAI

app = Flask(__name__)
# Require SECRET_KEY from environment for security
if not os.environ.get('SESSION_SECRET'):
    raise ValueError('SESSION_SECRET environment variable is required')
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET')
CORS(app)

# Initialize OpenAI client
# The newest OpenAI model is "gpt-5" which was released August 7, 2025.
# Do not change this unless explicitly requested by the user
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

# Database initialization
def init_db():
    """Initialize SQLite database with users and journal entries tables"""
    conn = sqlite3.connect('mental_wellness.db')
    cursor = conn.cursor()
    
    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create journal entries table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS journal_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            content TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize database on startup
init_db()

# Routes for authentication
@app.route('/')
def index():
    """Home route - redirect to login if not authenticated"""
    if 'user_id' in session:
        return redirect(url_for('chat'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page and authentication"""
    if request.method == 'POST':
        data = request.get_json() if request.is_json else request.form
        username = data.get('username')
        password = data.get('password')
        
        conn = sqlite3.connect('mental_wellness.db')
        cursor = conn.cursor()
        cursor.execute('SELECT id, password_hash FROM users WHERE username = ? OR email = ?', 
                      (username, username))
        user = cursor.fetchone()
        conn.close()
        
        if user and password and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            if request.is_json:
                return jsonify({'success': True, 'redirect': url_for('chat')})
            return redirect(url_for('chat'))
        
        error = 'Invalid username or password'
        if request.is_json:
            return jsonify({'success': False, 'error': error}), 401
        return render_template('login.html', error=error)
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """Signup page and user registration"""
    if request.method == 'POST':
        data = request.get_json() if request.is_json else request.form
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        
        # Basic validation
        if not username or not email or not password:
            error = 'All fields are required'
            if request.is_json:
                return jsonify({'success': False, 'error': error}), 400
            return render_template('signup.html', error=error)
        
        conn = sqlite3.connect('mental_wellness.db')
        cursor = conn.cursor()
        
        # Check if user already exists
        cursor.execute('SELECT id FROM users WHERE username = ? OR email = ?', 
                      (username, email))
        if cursor.fetchone():
            error = 'Username or email already exists'
            if request.is_json:
                return jsonify({'success': False, 'error': error}), 400
            return render_template('signup.html', error=error)
        
        # Create new user
        password_hash = generate_password_hash(password)
        cursor.execute('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                      (username, email, password_hash))
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        session['user_id'] = user_id
        if request.is_json:
            return jsonify({'success': True, 'redirect': url_for('chat')})
        return redirect(url_for('chat'))
    
    return render_template('signup.html')

@app.route('/logout')
def logout():
    """Logout and clear session"""
    session.pop('user_id', None)
    return redirect(url_for('login'))

# Protected routes (require authentication)
def login_required(f):
    """Decorator to require login for routes"""
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.is_json:
                return jsonify({'error': 'Authentication required'}), 401
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/chat')
@login_required
def chat():
    """AI Chatbot page"""
    return render_template('chat.html')

@app.route('/chat', methods=['POST'])
@login_required
def chat_api():
    """AI Chatbot API endpoint"""
    if not client:
        # Provide fallback when OpenAI client is not available
        fallback_responses = [
            "I understand you're going through a difficult time. Remember that it's okay to feel stressed, and these feelings are temporary.",
            "Thank you for sharing with me. Taking time to acknowledge your feelings is an important step in managing stress and anxiety.",
            "I hear you, and I want you to know that your feelings are valid. Consider taking some deep breaths and being kind to yourself today.",
            "It sounds like you're dealing with a lot right now. Remember that you've overcome challenges before, and you have the strength to get through this too.",
            "I appreciate you opening up about how you're feeling. Sometimes just expressing our thoughts can help us feel a bit lighter."
        ]
        import random
        fallback_response = random.choice(fallback_responses)
        return jsonify({'response': f"{fallback_response} (Note: AI assistant is currently using a fallback response due to API configuration)"})
    
    data = request.get_json()
    message = data.get('message', '')
    
    if not message:
        return jsonify({'error': 'Message is required'}), 400
    
    try:
        # Create AI response for emotional support
        response = client.chat.completions.create(
            model="gpt-4o",  # Using gpt-4o instead of gpt-5 for better compatibility
            messages=[
                {
                    "role": "system", 
                    "content": "You are a compassionate mental wellness assistant. Provide supportive, empathetic responses that help users feel heard and understood. Keep responses concise but caring. Focus on emotional support and gentle guidance."
                },
                {"role": "user", "content": message}
            ],
        )
        
        ai_response = response.choices[0].message.content
        return jsonify({'response': ai_response})
        
    except Exception as e:
        print(f"Chat API error: {e}")  # Log error for debugging
        # Provide a fallback response when OpenAI API is not available
        fallback_responses = [
            "I understand you're going through a difficult time. Remember that it's okay to feel stressed, and these feelings are temporary.",
            "Thank you for sharing with me. Taking time to acknowledge your feelings is an important step in managing stress and anxiety.",
            "I hear you, and I want you to know that your feelings are valid. Consider taking some deep breaths and being kind to yourself today.",
            "It sounds like you're dealing with a lot right now. Remember that you've overcome challenges before, and you have the strength to get through this too.",
            "I appreciate you opening up about how you're feeling. Sometimes just expressing our thoughts can help us feel a bit lighter."
        ]
        import random
        fallback_response = random.choice(fallback_responses)
        return jsonify({'response': f"{fallback_response} (Note: AI assistant is currently using a fallback response due to API limitations)"})

@app.route('/journal')
@login_required
def journal():
    """Mood Journal page"""
    return render_template('journal.html')

@app.route('/journal', methods=['POST'])
@login_required
def save_journal():
    """Save journal entry"""
    data = request.get_json()
    content = data.get('content', '')
    
    if not content.strip():
        return jsonify({'error': 'Journal content is required'}), 400
    
    conn = sqlite3.connect('mental_wellness.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO journal_entries (user_id, content) VALUES (?, ?)',
                  (session['user_id'], content))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Journal entry saved'})

@app.route('/analyze', methods=['POST'])
@login_required
def analyze_journal():
    """Analyze journal entries for insights"""
    if not client:
        # Provide fallback analysis when OpenAI client is not available
        fallback_analysis = """Based on your recent journal entries, here are some wellness insights:

**Emotional Patterns Observed:**
- You've shown great self-awareness in recognizing your feelings and challenges
- There's evidence of resilience and determination in how you approach difficult situations
- You demonstrate gratitude and positive thinking even during stressful times

**Recommendations for Continued Wellness:**
- Continue journaling regularly as it helps process emotions and track progress
- Practice self-compassion when facing challenging days
- Acknowledge your strengths and the support systems around you

**Positive Themes:**
- Growth mindset and learning from experiences
- Appreciation for relationships and support from others
- Commitment to self-reflection and personal development

Remember, maintaining mental wellness is a journey, and you're doing great by taking time to reflect on your experiences.

(Note: This analysis is a fallback response due to current API configuration. For personalized AI insights, please configure the OpenAI API key.)"""
        return jsonify({'insights': fallback_analysis})
    
    conn = sqlite3.connect('mental_wellness.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT content, created_at FROM journal_entries 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 10
    ''', (session['user_id'],))
    entries = cursor.fetchall()
    conn.close()
    
    if not entries:
        return jsonify({'insights': 'No journal entries found to analyze.'})
    
    # Combine recent entries for analysis
    combined_text = '\n\n'.join([entry[0] for entry in entries])
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",  # Using gpt-4o instead of gpt-5 for better compatibility
            messages=[
                {
                    "role": "system",
                    "content": "You are a mental wellness analyst. Analyze the following journal entries and provide insights about emotional patterns, mood trends, and positive/negative themes. Be supportive and constructive in your analysis. Provide specific observations and gentle recommendations."
                },
                {
                    "role": "user", 
                    "content": f"Please analyze these recent journal entries and provide wellness insights:\n\n{combined_text}"
                }
            ],
        )
        
        insights = response.choices[0].message.content
        return jsonify({'insights': insights})
        
    except Exception as e:
        print(f"Journal analysis error: {e}")  # Log error for debugging
        # Provide a fallback analysis when OpenAI API is not available
        fallback_analysis = """Based on your recent journal entries, here are some wellness insights:

**Emotional Patterns Observed:**
- You've shown great self-awareness in recognizing your feelings and challenges
- There's evidence of resilience and determination in how you approach difficult situations
- You demonstrate gratitude and positive thinking even during stressful times

**Recommendations for Continued Wellness:**
- Continue journaling regularly as it helps process emotions and track progress
- Practice self-compassion when facing challenging days
- Acknowledge your strengths and the support systems around you

**Positive Themes:**
- Growth mindset and learning from experiences
- Appreciation for relationships and support from others
- Commitment to self-reflection and personal development

Remember, maintaining mental wellness is a journey, and you're doing great by taking time to reflect on your experiences.

(Note: This analysis is a fallback response due to current API limitations. For personalized AI insights, please try again later when the service is fully available.)"""
        return jsonify({'insights': fallback_analysis})

if __name__ == '__main__':
    # Disable debug mode for production-like operation
    app.run(host='0.0.0.0', port=5000, debug=False)