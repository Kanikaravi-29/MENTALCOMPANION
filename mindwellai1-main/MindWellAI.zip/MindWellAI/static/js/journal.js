// Mental Wellness Assistant - Journal functionality

document.addEventListener('DOMContentLoaded', function() {
    const journalContent = document.getElementById('journalContent');
    const saveButton = document.getElementById('saveJournal');
    const analyzeButton = document.getElementById('analyzeJournal');
    const messageDiv = document.getElementById('journalMessage');
    const insightsContainer = document.getElementById('insightsContainer');
    const insightsContent = document.getElementById('insightsContent');

    async function saveJournalEntry() {
        const content = journalContent.value.trim();
        if (!content) {
            showMessage(messageDiv, 'Please write something in your journal first.', 'error');
            return;
        }

        setLoading(saveButton, true);

        try {
            const response = await fetch('/journal', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ content: content })
            });

            const data = await response.json();

            if (response.ok) {
                showMessage(messageDiv, 'Journal entry saved successfully!', 'success');
                journalContent.value = ''; // Clear after saving
            } else {
                showMessage(messageDiv, data.error || 'Failed to save journal entry.', 'error');
            }
        } catch (error) {
            console.error('Save error:', error);
            showMessage(messageDiv, 'Network error. Please try again.', 'error');
        } finally {
            setLoading(saveButton, false);
        }
    }

    async function analyzeJournal() {
        setLoading(analyzeButton, true);
        insightsContainer.style.display = 'none';

        try {
            const response = await fetch('/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();

            if (response.ok) {
                insightsContent.textContent = data.insights;
                insightsContainer.style.display = 'block';
                showMessage(messageDiv, 'Analysis complete! Check your insights below.', 'success');
            } else {
                showMessage(messageDiv, data.error || 'Failed to analyze journal entries.', 'error');
            }
        } catch (error) {
            console.error('Analysis error:', error);
            showMessage(messageDiv, 'Network error. Please try again.', 'error');
        } finally {
            setLoading(analyzeButton, false);
        }
    }

    saveButton.addEventListener('click', saveJournalEntry);
    analyzeButton.addEventListener('click', analyzeJournal);
    
    // Auto-save draft functionality (optional enhancement)
    let autoSaveTimer;
    journalContent.addEventListener('input', function() {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(() => {
            const content = journalContent.value.trim();
            if (content) {
                localStorage.setItem('journalDraft', content);
            }
        }, 1000);
    });
    
    // Load draft on page load
    const draft = localStorage.getItem('journalDraft');
    if (draft) {
        journalContent.value = draft;
    }
    
    // Clear draft when entry is saved
    saveButton.addEventListener('click', function() {
        localStorage.removeItem('journalDraft');
    });
});