// Mental Wellness Assistant - Chat functionality

document.addEventListener('DOMContentLoaded', function() {
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function addMessage(content, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = isUser ? 'user-message' : 'bot-message';
        
        const bubbleDiv = document.createElement('div');
        bubbleDiv.className = isUser ? 'message-bubble user-bubble' : 'message-bubble bot-bubble';
        bubbleDiv.textContent = content;
        
        messageDiv.appendChild(bubbleDiv);
        chatMessages.appendChild(messageDiv);
        
        scrollToBottom();
    }

    async function sendMessage() {
        const message = messageInput.value.trim();
        if (!message) return;

        // Add user message to chat
        addMessage(message, true);
        messageInput.value = '';
        
        // Disable send button
        setLoading(sendButton, true);

        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: message })
            });

            const data = await response.json();

            if (response.ok) {
                addMessage(data.response, false);
            } else {
                addMessage('Sorry, I encountered an error. Please try again.', false);
                console.error('Chat error:', data.error);
            }
        } catch (error) {
            console.error('Network error:', error);
            addMessage('Sorry, I had trouble connecting. Please check your internet connection and try again.', false);
        } finally {
            setLoading(sendButton, false);
        }
    }

    sendButton.addEventListener('click', sendMessage);
    
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Focus input on load
    messageInput.focus();
});