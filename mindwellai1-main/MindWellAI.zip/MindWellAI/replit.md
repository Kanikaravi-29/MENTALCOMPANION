# Mental Wellness Assistant Prototype

## Overview
A Flask-based web application that provides mental wellness support through AI-powered chatbot interactions and journal analysis. The app features user authentication, mood journaling, and AI-generated insights for emotional wellbeing.

## Current Status
**Completed Prototype** - All core features implemented and tested:
- ✅ User authentication (signup/login) with SQLite database
- ✅ AI chatbot with emotional support responses
- ✅ Journal entry system with AI analysis
- ✅ Clean, professional UI with specified design requirements
- ✅ Fallback systems for OpenAI API limitations
- ✅ Security measures implemented (SESSION_SECRET, debug mode off)

## Architecture
- **Backend**: Flask (Python 3.11) with SQLite database
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **AI Integration**: OpenAI API (gpt-4o) with fallback responses
- **Authentication**: Session-based with password hashing
- **Styling**: Professional theme (#f8f9fa background, #3b82f6 accents)

## Features Implemented
1. **Login/Signup Page** - Clean forms with validation
2. **AI Chatbot Page** - Real-time chat with emotional support
3. **Mood Journal & Insights** - Entry saving and AI analysis

## Technical Notes
- OpenAI API integration uses gpt-4o model
- Fallback responses provide support when API is unavailable
- SQLite database auto-initializes on startup
- Session management with secure secret key requirements
- CORS enabled for development

## Security Measures
- SESSION_SECRET environment variable required
- Password hashing with Werkzeug
- Debug mode disabled in production
- API error handling with user-friendly fallbacks

## Files Structure
- `app.py` - Main Flask application
- `templates/` - HTML templates (login, signup, chat, journal)
- `static/css/styles.css` - Professional styling
- `static/js/` - JavaScript for interactivity
- `mental_wellness.db` - SQLite database (auto-created)

## Environment Requirements
- SESSION_SECRET (required)
- OPENAI_API_KEY (optional, fallbacks available)

## User Preferences
- Clean, minimal design with professional aesthetics
- Supportive, empathetic AI responses
- Secure user data handling
- Responsive design for various screen sizes

## Recent Changes (September 19, 2025)
- Implemented comprehensive fallback system for API limitations
- Fixed security issues (SESSION_SECRET enforcement, debug mode)
- Added proper error handling and user feedback
- Created complete authentication flow
- Implemented journal saving and analysis features
- Added professional CSS styling matching requirements